-- Adminer 4.7.1 PostgreSQL dump

CREATE TABLE "public"."Mate" (
    "Username" character(255) NOT NULL,
    "Mate" character(255) NOT NULL,
    CONSTRAINT "Mate_Mate_fkey" FOREIGN KEY ("Mate") REFERENCES "User"("Username") NOT DEFERRABLE,
    CONSTRAINT "Mate_Username_fkey" FOREIGN KEY ("Username") REFERENCES "User"("Username") NOT DEFERRABLE
) WITH (oids = false);


CREATE TABLE "public"."Permission" (
    "SecretID" integer NOT NULL,
    "Username" character(255) NOT NULL,
    CONSTRAINT "Permission_SecretID_fkey" FOREIGN KEY ("SecretID") REFERENCES "Secret"("SecretID") NOT DEFERRABLE,
    CONSTRAINT "Permission_Username_fkey" FOREIGN KEY ("Username") REFERENCES "User"("Username") NOT DEFERRABLE
) WITH (oids = false);


CREATE SEQUENCE "Secret_SecretID_seq" INCREMENT  MINVALUE  MAXVALUE  START 1 CACHE ;

CREATE TABLE "public"."Secret" (
    "SecretID" integer DEFAULT nextval('"Secret_SecretID_seq"') NOT NULL,
    "Content" text NOT NULL,
    "Owner" character(255) NOT NULL,
    CONSTRAINT "Secret_SecretID" PRIMARY KEY ("SecretID"),
    CONSTRAINT "Secret_Owner_fkey" FOREIGN KEY ("Owner") REFERENCES "User"("Username") NOT DEFERRABLE
) WITH (oids = false);


CREATE TABLE "public"."Session" (
    "Token" character(255) NOT NULL,
    "IssuedDate" date NOT NULL,
    "Username" character(255) NOT NULL,
    CONSTRAINT "Session_Token" PRIMARY KEY ("Token"),
    CONSTRAINT "Session_Username_fkey" FOREIGN KEY ("Username") REFERENCES "User"("Username") NOT DEFERRABLE
) WITH (oids = false);


CREATE TABLE "public"."User" (
    "Username" character(255) NOT NULL,
    "Password" character(255) NOT NULL,
    CONSTRAINT "user_pkey" PRIMARY KEY ("Username")
) WITH (oids = false);

INSERT INTO "User" ("Username", "Password") VALUES
('John                                                                                                                                                                                                                                                           ',	'A8CFCD74832004951B4408CDB0A5DBCD8C7E52D43F7FE244BF720582E05241DA                                                                                                                                                                                               '),
('Mark                                                                                                                                                                                                                                                           ',	'D7CDA0CA2C8586E512C425368FCB2BBA62E81475BFCEB4284F4906DE8EC242BC                                                                                                                                                                                               '),
('Bill                                                                                                                                                                                                                                                           ',	'E51783B4D7688FFBA51A35D8C9F04041606C0D6FB00BB306FBA0F2DCB7E1F890                                                                                                                                                                                               '),
('Peter                                                                                                                                                                                                                                                          ',	'EA72C79594296E45B8C2A296644D988581F58CFAC6601D122ED0A8BD7C02E8BF                                                                                                                                                                                               ');

-- 2019-05-01 18:45:17.553191+00
